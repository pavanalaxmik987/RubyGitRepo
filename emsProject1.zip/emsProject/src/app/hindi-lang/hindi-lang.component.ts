import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hindi-lang',
  templateUrl: './hindi-lang.component.html',
  styleUrls: ['./hindi-lang.component.css']
})
export class HindiLangComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
