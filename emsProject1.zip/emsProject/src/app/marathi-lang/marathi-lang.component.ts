import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marathi-lang',
  templateUrl: './marathi-lang.component.html',
  styleUrls: ['./marathi-lang.component.css']
})
export class MarathiLangComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
