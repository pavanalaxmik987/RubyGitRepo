import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllLangComponent } from './all-lang.component';

describe('AllLangComponent', () => {
  let component: AllLangComponent;
  let fixture: ComponentFixture<AllLangComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllLangComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllLangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
