import { Component, OnInit } from '@angular/core';
import {RouterModule,Router} from '@angular/router';

@Component({
  selector: 'app-all-lang',
  templateUrl: './all-lang.component.html',
  styleUrls: ['./all-lang.component.css']
})
export class AllLangComponent implements OnInit {
hindisrc="/assets/images/hindi_kedar.jpg";
marathisrc="/assets/images/marathi_gateway.jpg";
kannadasrc="/assets/images/kannada_karnataka.jpg";
  constructor(private router:Router) { }

  ngOnInit() {
  }
  gallery(e){
    e.preventDefault();
    this.router.navigate(['hindi-lang']);
    return false;
    
  }
}
