import { UserService } from './user.service';
import { User } from './user';
import { Component, OnInit } from "@angular/core";


@Component({
    selector: 'app-users',
    template: `<h1>Welcome {{username}}</h1>
        <ul>
        <li *ngFor="let user of userlist;let i=index">{{user.username}}<input type="button" (click)="remove(i)" value="Delete"/></li>
        </ul>
    
    
    
    `,
    providers:[{provide:UserService,useClass:UserService}]

})
export class AllUserComponent implements OnInit {
    
    //AllUserComponent Depend on UserService only services can be injected into comp
    //cannot use one components as a parameter in anothe rcomponent
    username: string = "Tina"
    userlist: Array<User>;
    constructor(private userservice:UserService){
        console.log("User component invoked");
       

    }

    ngOnInit(): void {
        console.log("Ngoninit");
        this.userlist=this.userservice.getUser();
    }
   
}