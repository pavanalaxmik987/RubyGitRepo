import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Readers World!!!';
  hindisrc="/assets/images/hindi_kedar.jpg";
marathisrc="/assets/images/marathi_gateway.jpg";
kannadasrc="/assets/images/kannada_karnataka.jpg";
  appStyle= {  
    'color': 'blue',  
    'font-weight': 'bold',  
    'font-size': '25px',  
    'padding': '1rem',  
    'text-align':'center',
   
    'background-repeat': 'no-repeat',
    
    'background-position':'absolute',
    'background-size': 'cover',
    
    'width': '700px',
    'margin': 'auto',
    'border': '3px solid black'
};  
constructor(private router:Router){

}
selectedlang='' ;
selectLanguage(newvalue) {
   
  this.selectedlang = newvalue;  

}  

text=''
notify(e){
console.log(e);

e.preventDefault();
var option=e.target.elements[0].value;
var email=e.target.elements[1].value;
console.log(option,email);
if(option=="none" || email==" ")
{
  this.text="Please Select language and enter valid email"
  this.router.navigate(['notify-me']);
 
}
else{
   this.text="ypu will be notified soon Notification send to emailId "+ email
this.router.navigate(['notify-me']);

}
return false;


}

}
