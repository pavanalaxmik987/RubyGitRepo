import { MenuComponent } from './menu.component';
import { LoginService } from './login.service';
import { OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { Component } from '@angular/core';
import { Product } from './product';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[{provide:ProductService,useClass:ProductService},LoginService]

})
export class AppComponent  implements OnInit{ 
 index:number;
 id11:any;


hover:boolean; 
  product:Array<Product>;
  constructor(private productList:ProductService){

  }
  ngOnInit(): void {
    this.product=this.productList.getProductList();
  }
  mouseover(i:number){
    this.index=i;
   this.hover=true

  }
  i:number;
display(index:number){
  return this.product[index];
  //console.log(this.product[index]);
   }
}
 