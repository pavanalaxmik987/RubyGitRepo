import { PageNotFoundComponent } from './pagenotfound.component';
import { LoginComponent } from './login.component';
import { HeaderComponent } from './header.component';
import { FormsModule } from '@angular/forms';
import { MenuComponent } from './menu.component';
import { RouterModule, Routes } from '@angular/router';
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { AllUserComponent }  from './allusers.component';


let routes:Routes=[

  {
    path:'',
    component:LoginComponent
  },
  {
    path:'home',
    component:LoginComponent
  },
 
  {
    path:'user',
    component:AllUserComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'**',
    component:PageNotFoundComponent
  }
 

]
@NgModule({
  imports:      [ BrowserModule,FormsModule,RouterModule.forRoot(routes)],
  declarations: [ AppComponent,AllUserComponent,HeaderComponent,LoginComponent,MenuComponent,PageNotFoundComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
