import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { HoverDirective } from './hover.directive';
import { HindiLangComponent } from './hindi-lang/hindi-lang.component';
import { AllLangComponent } from './all-lang/all-lang.component';
import { MarathiLangComponent } from './marathi-lang/marathi-lang.component';
import { KannadaLangComponent } from './kannada-lang/kannada-lang.component';
import { NotifyMeComponent } from './notify-me/notify-me.component';
import { noComponentFactoryError } from '@angular/core/src/linker/component_factory_resolver';

const appRoute:Routes=[
  {
    path:'all-lang',
    component:AllLangComponent
  },
  {
    path:'marathi-lang',
    component:MarathiLangComponent
  },
  {
    path:'kannada-lang',
    component:KannadaLangComponent
  },
  {
    path:'hindi-lang',
    component:HindiLangComponent
  },
  {
    path:'notify-me',
    component:NotifyMeComponent
  },

{
  path:'',
  component:AppComponent
}

]

@NgModule({
  declarations: [
    AppComponent,
    HoverDirective,
    HindiLangComponent,
    AllLangComponent,
    MarathiLangComponent,
    KannadaLangComponent,
    NotifyMeComponent

  ],
  imports: [
    RouterModule.forRoot(appRoute),
    BrowserModule
   

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
