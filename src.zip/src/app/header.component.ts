import { LoginService } from './login.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@Component({
    selector: 'header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css'],
    
})
export class HeaderComponent implements OnInit {
    username:string;
    constructor(private loginService:LoginService) { }

    ngOnInit() { 
        //lamda or fat arrow syntax
        //feature of typescript
        this.loginService.getUsername().subscribe(newvalue=>this.username=newvalue); 
     
    
}
}