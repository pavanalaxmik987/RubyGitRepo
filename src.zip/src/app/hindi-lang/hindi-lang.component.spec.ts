import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HindiLangComponent } from './hindi-lang.component';

describe('HindiLangComponent', () => {
  let component: HindiLangComponent;
  let fixture: ComponentFixture<HindiLangComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HindiLangComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HindiLangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
