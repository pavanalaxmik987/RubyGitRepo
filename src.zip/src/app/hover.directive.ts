import { Directive,
  HostListener,
  ElementRef } from '@angular/core';

@Directive({
  selector: '[appHover]'
})
export class HoverDirective {
  @HostListener('mouseleave') onmosueleave() {  
    this.changecolor("Blue");  
}  
@HostListener('mouseover') onmouseover() {  
    this.changecolor("white");  
}  
 
@HostListener('mouseover') onmouseoverimg() {  
    this.changeimg("url('/assets/images/bg2.jpg')");  
    this.changecolor("white");  
}  
@HostListener('mouseleave') onmosueleaveimg() {  
    this.changeimg("url('/assets/images/bgred.jpg')"); 
    this.changecolor("green"); 
} 
changeimg(img: string): void {  
    this.elem.nativeElement.style.backgroundImage =img;  
}  
changecolor(colorname: string): void {  
    this.elem.nativeElement.style.color = colorname;  
    console.log(this.elem)
}  

constructor(private elem: ElementRef) {}

}
