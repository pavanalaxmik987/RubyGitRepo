import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KannadaLangComponent } from './kannada-lang.component';

describe('KannadaLangComponent', () => {
  let component: KannadaLangComponent;
  let fixture: ComponentFixture<KannadaLangComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KannadaLangComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KannadaLangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
