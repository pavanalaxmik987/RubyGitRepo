import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kannada-lang',
  templateUrl: './kannada-lang.component.html',
  styleUrls: ['./kannada-lang.component.css']
})
export class KannadaLangComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
