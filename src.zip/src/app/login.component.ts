import { LoginService } from './login.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css'],
  
})
export class LoginComponent implements OnInit {
    username:string="admin";
    password:string="admin";
    constructor(private loginService:LoginService,private router:Router) { }

    ngOnInit() { }
    login()
    {
        this.loginService.setUsername(this.username);
        console.log("setting Username in ogin comp")
        this.router.navigate(["/user"]);
        
    }
}