import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class LoginService {
    //called by  logincomponent
    nameSubj=new Subject<string>();
   
    setUsername(newname:string){
        
        this.nameSubj.next(newname);
        console.log("Setting name login component")
    }
    //called by headercomponent
    getUsername():Observable<string>{
        console.log("getting name Header component");
        return this.nameSubj.asObservable();
       
    }
}