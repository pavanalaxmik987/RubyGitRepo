import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarathiLangComponent } from './marathi-lang.component';

describe('MarathiLangComponent', () => {
  let component: MarathiLangComponent;
  let fixture: ComponentFixture<MarathiLangComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarathiLangComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarathiLangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
