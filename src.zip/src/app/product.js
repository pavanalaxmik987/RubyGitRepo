"use strict";
var Product = (function () {
    function Product(id, name, price, discountedPrice, quantity, brand, rating, image) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.discountedPrice = discountedPrice;
        this.quantity = quantity;
        this.brand = brand;
        this.rating = rating;
        this.image = image;
    }
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=product.js.map