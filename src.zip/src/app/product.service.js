"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var product_1 = require("./product");
var ProductService = (function () {
    function ProductService() {
        this.productList = new Array();
        var product1 = new product_1.Product(1, "MI", 12000, 11000, 1, "A", 3, "assets/images/p1.jpg");
        var product2 = new product_1.Product(2, "MI", 12000, 11000, 1, "A", 3, "assets/images/p2.jpg");
        var product3 = new product_1.Product(3, "MI", 12000, 11000, 1, "A", 3, "assets/images/p3.jpg");
        var product4 = new product_1.Product(4, "MI", 12000, 11000, 1, "A", 3, "assets/images/p4.jpg");
        var product5 = new product_1.Product(5, "MI", 12000, 11000, 1, "A", 3, "assets/images/p5.jpg");
        var product6 = new product_1.Product(6, "MI", 12000, 11000, 1, "A", 3, "assets/images/p6.jpg");
        var product7 = new product_1.Product(7, "MI", 12000, 11000, 1, "A", 3, "assets/images/p7.jpg");
        var product8 = new product_1.Product(8, "MI", 12000, 11000, 1, "A", 3, "assets/images/p8.jpg");
        var product9 = new product_1.Product(9, "MI", 12000, 11000, 1, "A", 3, "assets/images/p9.jpg");
        var product10 = new product_1.Product(10, "MI", 12000, 11000, 1, "A", 3, "assets/images/p10.jpg");
        this.productList.push(product1);
        this.productList.push(product2);
        this.productList.push(product3);
        this.productList.push(product4);
        this.productList.push(product5);
        this.productList.push(product6);
        this.productList.push(product7);
        this.productList.push(product8);
        this.productList.push(product9);
        this.productList.push(product10);
    }
    ProductService.prototype.getProductList = function () {
        return this.productList;
    };
    return ProductService;
}());
ProductService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], ProductService);
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map