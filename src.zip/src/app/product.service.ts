import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable()
export class ProductService{
    private productList:Array<Product>;
    constructor(){
        this.productList = new Array<Product>();
       let product1=new Product(1,"MI",12000,11000,1,"A",3,"assets/images/p1.jpg")
       let product2=new Product(2,"MI",12000,11000,1,"A",3,"assets/images/p2.jpg")
       let product3=new Product(3,"MI",12000,11000,1,"A",3,"assets/images/p3.jpg")
       let product4=new Product(4,"MI",12000,11000,1,"A",3,"assets/images/p4.jpg")
       let product5=new Product(5,"MI",12000,11000,1,"A",3,"assets/images/p5.jpg")
       let product6=new Product(6,"MI",12000,11000,1,"A",3,"assets/images/p6.jpg")
       let product7=new Product(7,"MI",12000,11000,1,"A",3,"assets/images/p7.jpg")
       let product8=new Product(8,"MI",12000,11000,1,"A",3,"assets/images/p8.jpg")
       let product9=new Product(9,"MI",12000,11000,1,"A",3,"assets/images/p9.jpg")
       let product10=new Product(10,"MI",12000,11000,1,"A",3,"assets/images/p10.jpg")
       this.productList.push(product1);
       this.productList.push(product2);
       this.productList.push(product3);
       this.productList.push(product4);
       this.productList.push(product5);
       this.productList.push(product6);
       this.productList.push(product7);
       this.productList.push(product8);
       this.productList.push(product9);
       this.productList.push(product10);
       

    }
    getProductList()
    {
        return this.productList;
    }

}