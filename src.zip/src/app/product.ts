export class Product{
    id:Number;
    name:string;
    price:Number;
    discountedPrice:Number;
    quantity:Number;
    brand:String;
    rating:Number;
    image:String;
    constructor( id:Number,name:string, price:Number, discountedPrice:Number, quantity:Number, brand:String,rating:Number,image:String){
        this.id=id;
        this.name=name;
        this.price=price;
        this.discountedPrice=discountedPrice;
        this.quantity=quantity;
        this.brand=brand
        this.rating=rating
        this.image=image;
    }
}