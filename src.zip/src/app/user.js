"use strict";
var User = (function () {
    function User(username, phone) {
        this.username = username;
        this.phone = phone;
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=user.js.map