"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var user_1 = require("./user");
var UserService = (function () {
    function UserService() {
        console.log("User service invoked");
        this.userlist = new Array();
        var user1 = new user_1.User("aaa", 789673);
        var user2 = new user_1.User("bbb", 345673);
        var user3 = new user_1.User("ccc", 323473);
        var user4 = new user_1.User("ddd", 3473433);
        this.userlist.push(user1);
        this.userlist.push(user2);
        this.userlist.push(user3);
        this.userlist.push(user4);
    }
    UserService.prototype.getUser = function () {
        return this.userlist;
    };
    UserService.prototype.remove = function (index) {
        this.userlist.splice(index, 1);
    };
    return UserService;
}());
UserService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], UserService);
exports.UserService = UserService;
//# sourceMappingURL=user.service.js.map