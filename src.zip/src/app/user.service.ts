import { Injectable } from "@angular/core";
import { User } from "./user";

@Injectable()
export class UserService {
    private userlist: Array<User>;
    constructor() {
        console.log("User service invoked");
        this.userlist = new Array<User>();
        let user1 = new User("aaa", 789673);
        let user2 = new User("bbb", 345673);
        let user3 = new User("ccc", 323473);
        let user4 = new User("ddd", 3473433);
        this.userlist.push(user1);
        this.userlist.push(user2);
        this.userlist.push(user3);
        this.userlist.push(user4);
    }
    getUser() {
        return this.userlist;
    }
    remove(index: number): void {
        this.userlist.splice(index, 1)

    }
}