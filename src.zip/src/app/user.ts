export class User{
    username:string;
    phone:Number;
    isIndian:boolean;
    constructor(username:string,phone:Number){
        this.username=username;
        this.phone=phone;

    }
}